# Minion-Packet-Multiplier-Dupe
A macro that multiplies your packets and crashes your hypixel server in order to duplicate items.

HOW TO USE
Insert the mod into your mods folder located in .minecraft, then Start Minecraft in [forge 1.8.9](https://files.minecraftforge.net/net/minecraftforge/forge/index_1.8.9.html)

Once in hypixel skyblock, warp to your island and open a minion GUI, Next to the GUI there should be a button that says "Packet Multiplier" if its not there leave and rejoin hypixel
( PRESS RIGHT SHIFT TO START GUI )

Enjoy, don't dupe more than 500m per day as the method becomes detectable and you may be banned.
